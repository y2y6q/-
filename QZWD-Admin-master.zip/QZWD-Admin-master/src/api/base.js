/**
 * 接口域名的管理
 */
const base = {    
    sq: '/api',    //本机开发环境    
    bd: 'http://xxxxx22222.com/api'
}

export default base;