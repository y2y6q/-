/** 
 * api接口的统一出口
 */
// 咨询管理模块接口
import content from '@/api/content';
// 其他模块的接口……

// 导出接口
export default {    
    content,
    // ……
}