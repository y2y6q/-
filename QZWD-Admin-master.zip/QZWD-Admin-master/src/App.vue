<template>
  <div id="app">
    <router-view>
    </router-view>
  </div>
</template>
<style scoped>
*{
  padding: 0;
  margin: 0;
}
html,body{
  width: 100%;
  height: 100%;
}
#app {
  height: 100%;
}
</style>